#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include <string>
#include <map>
#include <queue>
using namespace llvm;

namespace {
class MyUnreachablePass : public PassInfoMixin<MyUnreachablePass> {
public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    std::map<std::string, bool> M;
    for(BasicBlock &BB : F) {
      M[std::string(BB.getName())] = false;
    }

    std::queue<BasicBlock*> Q;
    for(BasicBlock &BB : F) {
      Q.push(&BB); break;
    }
    while(!Q.empty()){
      BasicBlock *BB=Q.front(); Q.pop();
      std::string cur(BB->getName());
      if(M[cur]==true) continue;
      M[cur]=true;
      
      unsigned successorCnt = BB->getTerminator()->getNumSuccessors();
      for (unsigned i = 0; i < successorCnt; ++i) {
        BasicBlock *NextBB = BB->getTerminator()->getSuccessor(i);
        Q.push(NextBB);
      }
    }
    for(auto &e : M) {
      if(e.second==false) outs() << e.first << "\n";
    }
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "MyUnreachablePass", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "my-unreachable") {
            FPM.addPass(MyUnreachablePass());
            return true;
          }
          return false;
        }
      );
    }
  };
}
